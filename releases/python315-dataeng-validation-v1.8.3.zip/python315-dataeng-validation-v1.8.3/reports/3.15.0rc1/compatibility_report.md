# Compatibility Report — Python 3.15.0rc1

**Date:** June 05, 2026
**Platform:** macOS 26.5 ARM64
**Tester:** Dr. Ceasar Jackson Jr.
**Suite Version:** 1.2.0

---

## Summary

| Metric | Value |
|--------|-------|
| Packages Tested | 17 |
| PASS | 13 |
| INCOMPAT | 1 |
| SKIP | 1 |
| FAIL | 0 |

---

## Core Stack

| Package | Version | Result | Notes |
|---------|---------|--------|-------|
| numpy | 2.4.6 | ✅ PASS |  |
| pandas | 3.0.3 | ✅ PASS |  |
| polars | 1.41.2 | ✅ PASS |  |
| duckdb | 1.5.3 | ✅ PASS |  |
| sqlalchemy | 2.0.50 | ✅ PASS |  |
| pydantic | 2.13.4 | ✅ PASS |  |
| matplotlib | 3.10.9 | ✅ PASS |  |
| plotly | 6.7.0 | ✅ PASS |  |
| jupyterlab | 4.5.7 | ✅ PASS |  |
| sqlite3 | 3.53.1 | ✅ PASS |  |

## Extended Stack

| Package | Version | Result | Notes |
|---------|---------|--------|-------|
| pyspark | 4.1.2 | ✅ PASS | via Docker py314 + OpenJDK 21 |
| dask.dataframe | 2026.3.0 | ⚠️ INCOMPAT | runtime pyarrow dep |
| pyarrow | unavailable | 🚫 BLOCKED | no cp315 wheels on PyPI; source build fails at CMake config |
| mlflow | 2.16.2 | ✅ PASS |  |
| prefect | 3.7.3 | ✅ PASS |  |
| ray | unavailable | 🚫 BLOCKED | no cp315 wheels on PyPI |
| apache-airflow | not installed | ⏭️ SKIP | deferred |

---

## Changes from Previous Cycle

*Compare with previous report using:*
```bash
python scripts/compare_reports.py <previous> 3.15.0rc1
```

---

*Generated 2026-06-05 by Python 3.15 Data Engineering Validation Suite v1.2.0*